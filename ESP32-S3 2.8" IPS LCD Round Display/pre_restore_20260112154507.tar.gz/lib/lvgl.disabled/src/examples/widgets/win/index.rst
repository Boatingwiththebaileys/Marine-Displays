
Simple window
"""""""""""""""

.. lv_example:: widgets/win/lv_example_win_1
  :language: c

