#include "ui.h"


// IMAGE DATA: assets/Oil_Temp.bin (RGB565 binary)
const char *ui_img_oil_temp_png = "S:/assets/Oil_Temp.bin";
