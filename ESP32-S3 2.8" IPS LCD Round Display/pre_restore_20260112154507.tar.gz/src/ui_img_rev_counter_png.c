#include "ui.h"


// IMAGE DATA: assets/Rev_Counter.bin (RGB565 binary)
const char *ui_img_rev_counter_png = "S:/assets/Rev_Counter.bin";
