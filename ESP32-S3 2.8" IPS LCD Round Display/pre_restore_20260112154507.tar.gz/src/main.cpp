#include <Preferences.h>
// Minimal NVS test function
void test_nvs_minimal() {
    Preferences prefs;
    Serial.println("[NVS TEST] Writing test value...");
    prefs.begin("testspace", false);
    prefs.putInt("testkey", 12345);
    prefs.end();

    Serial.println("[NVS TEST] Reading test value...");
    prefs.begin("testspace", true);
    int val = prefs.getInt("testkey", -1);
    Serial.printf("[NVS TEST] Read value: %d\n", val);
    prefs.end();
}
// Global test mode flag: disables live data updates when true
bool test_mode = false;
#include <Arduino.h>
#include "I2C_Driver.h"
#include "TCA9554PWR.h"
#include "Display_ST7701.h"
#include "LVGL_Driver.h"
#include "SD_Card.h"
#include "ui.h"
#include "signalk_config.h"
#include "screen_config_c_api.h"
#include "sensESP_setup.h"
#include "gauge_config.h"
#ifdef __cplusplus
extern "C" {
#endif
void show_fallback_error_screen_if_needed();
#ifdef __cplusplus
}
#endif
#include "esp_heap_caps.h"
#include "esp_system.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "rgb565_decoder.h"  // Custom decoder for binary RGB565 images

// External UI elements
extern lv_obj_t *ui_CoolantIcon;

// Animation state tracking
static int16_t current_needle_angle = 0;
static int16_t current_lower_needle_angle = 0;

// Global needle angle tracking for all screens (1-based: Screen1..Screen5)
int16_t last_top_angle[6] = {0, 0, 0, 0, 0, 0};     // [screen] - all start at 0°
int16_t last_bottom_angle[6] = {0, 180, 180, 180, 180, 180};  // [screen] - all start at 180°

// Buzzer alert function
void trigger_buzzer_alert() {
    // TODO: Implement buzzer functionality when ready
    // Example: Set_EXIO(EXIO_PIN8, High); delay(200); Set_EXIO(EXIO_PIN8, Low);
    Serial.println("Alert triggered!");
}

// Animation callback for upper needle
static void needle_anim_cb(void * var, int32_t v) {
    lv_obj_t* needle = (lv_obj_t*)var;
    if (needle != NULL) {
        float rad = (v - 90) * PI / 180.0;
        static lv_point_t points[2];
        points[0].x = 240 + (int16_t)(142 * cos(rad));
        points[0].y = 240 + (int16_t)(142 * sin(rad));
        points[1].x = 240 + (int16_t)(210 * cos(rad));
        points[1].y = 240 + (int16_t)(210 * sin(rad));
        lv_line_set_points(needle, points, 2);
    }
}

// Animation callback for lower needle
static void lower_needle_anim_cb(void * var, int32_t v) {
    lv_obj_t* needle = (lv_obj_t*)var;
    if (needle != NULL) {
        float rad = (v - 90) * PI / 180.0;
        static lv_point_t points[2];
        // Start needle 30 pixels from center to hide center connection
        points[0].x = 240 + (int16_t)(142 * cos(rad));
        points[0].y = 240 + (int16_t)(142 * sin(rad));
        points[1].x = 240 + (int16_t)(200 * cos(rad));
        points[1].y = 240 + (int16_t)(200 * sin(rad));
        lv_line_set_points(needle, points, 2);
    }
}

// Smooth animated needle updates - now fast with line-based rendering!
void rotate_needle(int16_t angle) {
    if (ui_Needle != NULL && angle != current_needle_angle) {
        lv_anim_t a;
        lv_anim_init(&a);
        lv_anim_set_var(&a, ui_Needle);
        lv_anim_set_exec_cb(&a, needle_anim_cb);
        lv_anim_set_values(&a, current_needle_angle, angle);
        lv_anim_set_time(&a, 300);  // 300ms smooth animation
        lv_anim_set_path_cb(&a, lv_anim_path_linear);
        lv_anim_start(&a);
        current_needle_angle = angle;
    }
}

void rotate_lower_needle(int16_t angle) {
    if (ui_Lower_Needle != NULL && angle != current_lower_needle_angle) {
        lv_anim_t a;
        lv_anim_init(&a);
        lv_anim_set_var(&a, ui_Lower_Needle);
        lv_anim_set_exec_cb(&a, lower_needle_anim_cb);
        lv_anim_set_values(&a, current_lower_needle_angle, angle);
        lv_anim_set_time(&a, 300);  // 300ms smooth animation
        lv_anim_set_path_cb(&a, lv_anim_path_linear);
        lv_anim_start(&a);
        current_lower_needle_angle = angle;
    }
}

// Convert frequency (Hz) to angle using configured range
int16_t hz_to_angle(float hz) {
    return gauge_top_value_to_angle(hz);
}

// Convert temperature (Kelvin) to angle using configured range
int16_t kelvin_to_angle(float kelvin) {
    return gauge_bottom_value_to_angle(kelvin);
}

// Convert fuel level (0-100%) to angle (0-360 degrees)
int16_t fuel_to_angle(float percent) {
    // Clamp to 0-100%
    if (percent < 0) percent = 0;
    if (percent > 100) percent = 100;
    // Map 0-100% to 0-360 degrees
    return (int16_t)((percent / 100.0) * 360.0);
}

// Convert exhaust temperature (Kelvin) to angle
// Typical range: 300K (27°C) to 900K (627°C)
int16_t exhaust_temp_to_angle(float kelvin) {
    float min_temp = 273.15 + 0;    // 0°C
    float max_temp = 273.15 + 700;  // 700°C
    
    if (kelvin < min_temp) kelvin = min_temp;
    if (kelvin > max_temp) kelvin = max_temp;
    
    float normalized = (kelvin - min_temp) / (max_temp - min_temp);
    return (int16_t)(normalized * 360.0);
}

// Convert oil pressure (bar) to angle
// Typical range: 0-6 bar
int16_t oil_pressure_to_angle(float bar) {
    float min_pressure = 0.0;
    float max_pressure = 6.0;
    
    if (bar < min_pressure) bar = min_pressure;
    if (bar > max_pressure) bar = max_pressure;
    
    float normalized = bar / max_pressure;
    return (int16_t)(normalized * 360.0);
}

// Unified conversion function for all parameter types
// param_type: 0=RPM, 1=Coolant Temp, 2=Fuel, 3=Exhaust Temp, 4=Oil Pressure
// New version: per-screen, per-gauge calibration
int16_t value_to_angle_for_param(float value, int screen, int gauge) {
    int16_t angle = gauge_value_to_angle_screen(value, screen, gauge);
    // Debug output disabled for performance
    return angle;
}

// Generic needle animation helper that caches the last angle per needle
static void animate_generic_needle(lv_obj_t* needle, int16_t &last_angle, int16_t new_angle, bool is_lower) {
    if (needle == NULL || new_angle == last_angle) return;

    lv_anim_t a;
    lv_anim_init(&a);
    lv_anim_set_var(&a, needle);
    lv_anim_set_exec_cb(&a, is_lower ? lower_needle_anim_cb : needle_anim_cb);
    lv_anim_set_values(&a, last_angle, new_angle);
    lv_anim_set_time(&a, 300);
    lv_anim_set_path_cb(&a, lv_anim_path_linear);
    lv_anim_start(&a);

    last_angle = new_angle;
}

// Initialize all needle positions to defaults: top needles at 0°, bottom needles at 180°
void initialize_needle_positions() {
    // Set all top needles to 0 degrees (pointing up)
    // Initialize line-based needles by calling the same callbacks used by animations
    if (ui_Needle) needle_anim_cb(ui_Needle, 0);
    if (ui_Needle2) needle_anim_cb(ui_Needle2, 0);
    if (ui_Needle3) needle_anim_cb(ui_Needle3, 0);
    if (ui_Needle4) needle_anim_cb(ui_Needle4, 0);
    if (ui_Needle5) needle_anim_cb(ui_Needle5, 0);

    // Set all bottom needles to 180 degrees (pointing down)
    if (ui_Lower_Needle) lower_needle_anim_cb(ui_Lower_Needle, 180);
    if (ui_Lower_Needle2) lower_needle_anim_cb(ui_Lower_Needle2, 180);
    if (ui_Lower_Needle3) lower_needle_anim_cb(ui_Lower_Needle3, 180);
    if (ui_Lower_Needle4) lower_needle_anim_cb(ui_Lower_Needle4, 180);
    if (ui_Lower_Needle5) lower_needle_anim_cb(ui_Lower_Needle5, 180);
}

// Update both needles for the active screen using live Signal K sensor values
void update_needles_for_screen(int screen_num) {
    // Index 1-5 correspond to Screen1..Screen5
    if (screen_num < 1 || screen_num > 5) return;
    // If test mode is active, skip all live data updates
    extern bool test_mode;
    if (test_mode) return;

    // Default angles: top needles at 0°, bottom needles at 180°
    static int16_t last_top_angle[6] = {0, 0, 0, 0, 0, 0};     // [screen] - all start at 0°
    static int16_t last_bottom_angle[6] = {0, 180, 180, 180, 180, 180};  // [screen] - all start at 180°
    static bool initialized[6] = {false, false, false, false, false, false}; // Track if needles have been set to defaults

    lv_obj_t* top_needle = NULL;
    lv_obj_t* bottom_needle = NULL;
    ParamType top_type = PARAM_RPM;
    ParamType bottom_type = PARAM_COOLANT_TEMP;
    float top_value = 0.0f;
    float bottom_value = 0.0f;

    switch (screen_num) {
        case 1:  // RPM + Coolant Temp
            top_needle = ui_Needle;
            bottom_needle = ui_Lower_Needle;
            top_value = get_sensor_value(SCREEN1_RPM);
            bottom_value = get_sensor_value(SCREEN1_COOLANT_TEMP);
            top_type = PARAM_RPM;
            bottom_type = PARAM_COOLANT_TEMP;
            // Debug output disabled for performance
            break;
        case 2:  // RPM + Fuel
            top_needle = ui_Needle2;
            bottom_needle = ui_Lower_Needle2;
            top_value = get_sensor_value(SCREEN2_RPM);
            bottom_value = get_sensor_value(SCREEN2_FUEL);
            top_type = PARAM_RPM;
            bottom_type = PARAM_FUEL;
            break;
        case 3:  // Coolant Temp + Exhaust Temp
            top_needle = ui_Needle3;
            bottom_needle = ui_Lower_Needle3;
            top_value = get_sensor_value(SCREEN3_COOLANT_TEMP);
            bottom_value = get_sensor_value(SCREEN3_EXHAUST_TEMP);
            top_type = PARAM_COOLANT_TEMP;
            bottom_type = PARAM_EXHAUST_TEMP;
            break;
        case 4:  // Fuel + Coolant Temp
            top_needle = ui_Needle4;
            bottom_needle = ui_Lower_Needle4;
            top_value = get_sensor_value(SCREEN4_FUEL);
            bottom_value = get_sensor_value(SCREEN4_COOLANT_TEMP);
            top_type = PARAM_FUEL;
            bottom_type = PARAM_COOLANT_TEMP;
            break;
        case 5:  // Oil Pressure + Coolant Temp
            top_needle = ui_Needle5;
            bottom_needle = ui_Lower_Needle5;
            top_value = get_sensor_value(SCREEN5_OIL_PRESSURE);
            bottom_value = get_sensor_value(SCREEN5_COOLANT_TEMP);
            top_type = PARAM_OIL_PRESSURE;
            bottom_type = PARAM_COOLANT_TEMP;
            break;
        default:
            return;
    }

    // Set defaults on first run, then use sensor data or keep defaults if no valid data
    int16_t top_angle, bottom_angle;
    
    if (!initialized[screen_num]) {
        // First run: set to defaults
        top_angle = 0;    // Top needles start at 0°
        bottom_angle = 180; // Bottom needles start at 180°
        initialized[screen_num] = true;
    } else {
        // Use sensor data if valid, otherwise keep current position
        if (top_value > 0 && !isnan(top_value)) {
            top_angle = value_to_angle_for_param(top_value, screen_num - 1, 0);  // 0 = top gauge
        } else {
            top_angle = last_top_angle[screen_num]; // Keep current position if no valid data
        }
        
        if (bottom_value > 0 && !isnan(bottom_value)) {
            bottom_angle = value_to_angle_for_param(bottom_value, screen_num - 1, 1);  // 1 = bottom gauge
        } else {
            bottom_angle = last_bottom_angle[screen_num]; // Keep current position if no valid data
        }
    }

    // Debug output disabled for performance

    // Debug: (removed) previously logged needle values here to reduce console noise.

    animate_generic_needle(top_needle, last_top_angle[screen_num], top_angle, false);
    animate_generic_needle(bottom_needle, last_bottom_angle[screen_num], bottom_angle, true);

    // Update dynamic icon recoloring for this screen/gauges based on current values
    lv_obj_t* top_icon = NULL;
    lv_obj_t* bottom_icon = NULL;

    switch (screen_num) {
        case 1:
            extern lv_obj_t *ui_TopIcon;
            top_icon = ui_TopIcon;
            bottom_icon = ui_CoolantIcon;
            break;
        case 2:
            extern lv_obj_t *ui_TopIcon2;
            top_icon = ui_TopIcon2;
            bottom_icon = ui_FuelIcon;
            break;
        case 3:
            extern lv_obj_t *ui_TopIcon3;
            top_icon = ui_TopIcon3;
            bottom_icon = ui_exhaustIcon;
            break;
        case 4:
            extern lv_obj_t *ui_TopIcon4;
            top_icon = ui_TopIcon4;
            bottom_icon = ui_FuelIcon2;
            break;
        case 5:
            extern lv_obj_t *ui_TopIcon5;
            top_icon = ui_TopIcon5;
            bottom_icon = ui_OilIcon;
            break;
        default:
            break;
    }

    if (top_icon) _ui_apply_icon_style(top_icon, screen_num - 1, 0);
    if (bottom_icon) _ui_apply_icon_style(bottom_icon, screen_num - 1, 1);
}

// Move the specified gauge (top/bottom) on a given screen to the specified angle for testing
void test_move_gauge(int screen, int gauge, int angle) {
    // screen: 0-4 (Screen1..Screen5), gauge: 0=top, 1=bottom
    lv_obj_t* top_needles[5] = {ui_Needle, ui_Needle2, ui_Needle3, ui_Needle4, ui_Needle5};
    lv_obj_t* bottom_needles[5] = {ui_Lower_Needle, ui_Lower_Needle2, ui_Lower_Needle3, ui_Lower_Needle4, ui_Lower_Needle5};
    extern int16_t last_top_angle[6];
    extern int16_t last_bottom_angle[6];
    if (screen < 0 || screen > 4) {
        // Debug output disabled for performance
        return;
    }
    int idx = screen + 1; // last_*_angle arrays are 1-based (Screen1..Screen5)
    // Debug output disabled for performance
    if (gauge == 0) {
        // Top gauge (line)
        if (top_needles[screen]) {
            lv_anim_t a;
            lv_anim_init(&a);
            lv_anim_set_var(&a, top_needles[screen]);
            lv_anim_set_exec_cb(&a, needle_anim_cb);
            lv_anim_set_values(&a, last_top_angle[idx], angle);
            lv_anim_set_time(&a, 300);
            lv_anim_set_path_cb(&a, lv_anim_path_linear);
            lv_anim_start(&a);
            last_top_angle[idx] = angle;
        } else {
            // Debug output disabled for performance
        }
    } else if (gauge == 1) {
        // Bottom gauge (line)
        if (bottom_needles[screen]) {
            lv_anim_t a;
            lv_anim_init(&a);
            lv_anim_set_var(&a, bottom_needles[screen]);
            lv_anim_set_exec_cb(&a, lower_needle_anim_cb);
            lv_anim_set_values(&a, last_bottom_angle[idx], angle);
            lv_anim_set_time(&a, 300);
            lv_anim_set_path_cb(&a, lv_anim_path_linear);
            lv_anim_start(&a);
            last_bottom_angle[idx] = angle;
        } else {
            // Debug output disabled for performance
        }
    } else {
        // Debug output disabled for performance
    }
}

void setup() {
        test_nvs_minimal();
    // Serial for debugging - with timeout
    Serial.setTxTimeoutMs(0);  // Non-blocking serial
    Serial.begin(115200);
    delay(500);
    
    Serial.println("\n\n=== ESP32 Round Display Starting ===");
    Serial.flush();
    
    // I2C and IO expander
    I2C_Init();
    delay(100);
    TCA9554PWR_Init(0x00);
    Set_EXIO(EXIO_PIN8, Low);    // Start with buzzer OFF
    Set_EXIO(EXIO_PIN3, Low);    // Keep other pins low
    Serial.println("I2C and IO expander initialized");
    Serial.flush();
    
    // LCD (now with reduced pixel clock + larger bounce buffer)
    LCD_Init();
    Serial.print("LCD initialized at ");
    Serial.print(ESP_PANEL_LCD_RGB_TIMING_FREQ_HZ / 1000000);  // MHz
    Serial.println("MHz pixel clock");
    Serial.flush();
    
    // SD Card (must be initialized before LVGL to load images)
    SD_Init();
    Serial.println("SD card initialized");
    Serial.flush();
    
    // Load persisted preferences BEFORE initializing the UI so dynamic image paths
    // are available during screen construction.
    load_preferences();
    // Optional: dump loaded configs for debugging
    dump_screen_configs();

    // Diagnostics: Print loaded config for each screen
    Serial.println("[DIAG] Loaded screen configs after reboot:");
    for (int s = 0; s < 5; ++s) {
        Serial.printf("[DIAG] Screen %d: icon_top='%s' icon_bottom='%s'\n", s,
            screen_configs[s].icon_paths[0], screen_configs[s].icon_paths[1]);
        for (int g = 0; g < 2; ++g) {
            for (int z = 1; z <= 4; ++z) {
                Serial.printf("[DIAG] S%d G%d Z%d: color='%s' transparent=%d min=%.2f max=%.2f\n",
                    s, g, z, screen_configs[s].color[g][z], screen_configs[s].transparent[g][z],
                    screen_configs[s].min[g][z], screen_configs[s].max[g][z]);
            }
        }
    }

    // Show fallback error screen if all configs are blank
    show_fallback_error_screen_if_needed();

    // LVGL
    Lvgl_Init();

    // Initialize RGB565 binary image decoder (fast loading, no PNG decode overhead)
    rgb565_decoder_init();
    Serial.println("RGB565 decoder initialized");
    Serial.flush();

    ui_init();  // Load SquareLine UI
    Serial.println("LVGL and UI initialized");
    Serial.flush();
    // Print UI image object pointers for diagnostics
    Serial.println("[UI PTR] Icon object pointers:");
    Serial.printf("  ui_CoolantIcon=%p\n", (void*)ui_CoolantIcon);
    extern lv_obj_t *ui_FuelIcon;
    extern lv_obj_t *ui_FuelIcon2;
    extern lv_obj_t *ui_exhaustIcon;
    extern lv_obj_t *ui_OilIcon;
    Serial.printf("  ui_FuelIcon=%p\n", (void*)ui_FuelIcon);
    Serial.printf("  ui_FuelIcon2=%p\n", (void*)ui_FuelIcon2);
    Serial.printf("  ui_exhaustIcon=%p\n", (void*)ui_exhaustIcon);
    Serial.printf("  ui_OilIcon=%p\n", (void*)ui_OilIcon);
    Serial.flush();
    
    // Initialize all needles to default positions
    initialize_needle_positions();
    Serial.println("Needle positions initialized");
    Serial.flush();
    
    // Initialize gauge configuration
    gauge_config_init();
    Serial.println("Gauge configuration loaded");
    Serial.flush();
    
    // Initialize sensor mutex for thread-safe access
    init_sensor_mutex();
    
    // Enable WiFi with optimizations
    Serial.println("Starting WiFi setup...");
    Serial.flush();
    setup_sensESP();
    Serial.println("WiFi setup complete");
    Serial.flush();
    
    // Start Signal K only if server is actually configured
    Serial.println("Checking Signal K configuration...");
    Serial.flush();
    String sk_ip = get_signalk_server_ip();
    Serial.print("Signal K Server IP: '");
    Serial.print(sk_ip);
    Serial.println("'");
    Serial.flush();
    
    if (sk_ip.length() > 0 && is_wifi_connected()) {
        Serial.println("Starting Signal K...");
        Serial.flush();
        enable_signalk("", "", sk_ip.c_str(), get_signalk_server_port());
    } else {
        Serial.println("Signal K not configured yet");
        Serial.println("Connect to web UI to configure Signal K server");
        Serial.flush();
    }
    
    Serial.println("Display initialized with WiFi optimizations.");
    Serial.print("WiFi SSID: ");
    Serial.println(WiFi.SSID());
    Serial.print("WiFi IP: ");
    Serial.println(WiFi.localIP());
    Serial.println("Navigate to http://esp32-rounddisplay.local or check your router for device IP");
    Serial.flush();
}

void loop() {
    config_server.handleClient();
    // Use Signal K data instead of demo animation
    static int16_t needle_angle = 0;
    static int16_t lower_needle_angle = 0;
    static unsigned long last_needle_update = 0;
    
    // Switch to Signal K mode
    static bool use_demo_mode = false;
    
    // Check if in setup mode - use preview angles instead of Signal K data
    if (gauge_is_setup_mode()) {
        int16_t top_angle = gauge_get_preview_top_angle();
        int16_t bottom_angle = gauge_get_preview_bottom_angle();
        Serial.print("[DEBUG] Setup mode active. Preview angles: top=");
        Serial.print(top_angle);
        Serial.print(", bottom=");
        Serial.println(bottom_angle);
        rotate_needle(top_angle);
        rotate_lower_needle(bottom_angle);
    } else if (use_demo_mode) {
        needle_angle = (needle_angle + 1) % 360;
        lower_needle_angle = (lower_needle_angle + 2) % 360;
        
        rotate_needle(needle_angle);
        rotate_lower_needle(lower_needle_angle);
    } else {
        // Use values from Signal K (automatically updated by background task)
        // Update needles every 100ms for smooth operation
        unsigned long now = millis();
        if (now - last_needle_update >= 100) {
            int current_screen = ui_get_current_screen();
            update_needles_for_screen(current_screen);
            last_needle_update = now;
        }
        
        // Update coolant icon color based on temperature (only when state changes)
        if (ui_CoolantIcon != NULL) {
            static int last_icon_state = -1;  // Track state: 0=blue, 1=hidden, 2=orange, 3=red
            static unsigned long last_alert_time = 0;  // Track when last alert was triggered
            static bool first_run = true;  // Allow first alert immediately
            const unsigned long ALERT_COOLDOWN_MS = 60000;  // 1 minute cooldown between alerts
            float temp = get_temperature_k();
            int current_state;
            
            // Determine zone using web-configured ranges in `screen_configs`.
            // Zones are 1..4. Default to zone 1 when nothing configured.
            int screen_idx = ui_get_current_screen() - 1;
            if (screen_idx < 0) screen_idx = 0;
            int gauge_idx = 1; // coolant icon is bottom gauge
            int chosen_zone = 1;
            for (int z = 1; z <= 4; ++z) {
                float mn = screen_configs[screen_idx].min[gauge_idx][z];
                float mx = screen_configs[screen_idx].max[gauge_idx][z];
                if (mn == mx) continue; // skip unconfigured zone
                if (!isnan(temp) && temp >= mn && temp <= mx) { chosen_zone = z; break; }
                if (isnan(temp) && (mn != 0.0f || mx != 0.0f)) { chosen_zone = z; break; }
            }
            // Map chosen_zone (1..4) to current_state (0..3): 0=blue,1=hidden,2=orange,3=red
            current_state = chosen_zone - 1;
            
            // Only update LVGL when state changes to avoid unnecessary redraws
            if (current_state != last_icon_state) {
                // New behavior: defer all styling/visibility to the web UI configuration
                // and the centralized helper `_ui_apply_icon_style`.
                // Remove legacy special-case that hid the icon for a specific zone.
                // Ensure the icon is visible and let the helper set opacity/recolor.
                lv_obj_clear_flag(ui_CoolantIcon, LV_OBJ_FLAG_HIDDEN);
                _ui_apply_icon_style(ui_CoolantIcon, ui_get_current_screen() - 1, 1);
                
                // Trigger buzzer alert when entering orange or red zone with cooldown timer
                extern void trigger_buzzer_alert();
                unsigned long now = millis();
                bool cooldown_expired = (now - last_alert_time > ALERT_COOLDOWN_MS);
                
                if ((current_state == 2 || current_state == 3) && (first_run || cooldown_expired)) {
                    trigger_buzzer_alert();
                    last_alert_time = now;
                    first_run = false;
                    printf("Temperature alert triggered at %.1f°C (cooldown: %lu min)\n", temp - 273.15, ALERT_COOLDOWN_MS / 60000);
                }
                
                last_icon_state = current_state;
            }
        }
    }
    
    Lvgl_Loop();

    // Small delay to prevent excessive loop iterations
    delay(1);
    yield();
}
