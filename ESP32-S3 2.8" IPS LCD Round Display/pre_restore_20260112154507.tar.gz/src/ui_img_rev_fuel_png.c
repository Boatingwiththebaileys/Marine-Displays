#include "ui.h"


// IMAGE DATA: assets/Rev_Fuel.bin (RGB565 binary)
const char *ui_img_rev_fuel_png = "S:/assets/Rev_Fuel.bin";
