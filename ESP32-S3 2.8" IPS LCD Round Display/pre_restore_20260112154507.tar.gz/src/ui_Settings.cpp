#include "ui_Settings.h"
#include "ui.h"
#include "Display_ST7701.h"
#include "TCA9554PWR.h"  // For buzzer control
#include <WiFi.h>

extern lv_obj_t *ui_Screen1;  // Reference to main screen

lv_obj_t *ui_Settings = NULL;
lv_obj_t *ui_SettingsPanel = NULL;
lv_obj_t *ui_BrightnessSlider = NULL;
lv_obj_t *ui_BrightnessLabel = NULL;
lv_obj_t *ui_IPLabel = NULL;
lv_obj_t *ui_BackButton = NULL;
lv_obj_t *ui_BuzzerSwitch = NULL;
lv_obj_t *ui_BuzzerLabel = NULL;

// Global buzzer mode: 0 = Off, 1 = Alert
int buzzer_mode = 0;

// Buzzer alert function - makes two beeps
void trigger_buzzer_alert() {
    if (buzzer_mode == 1) {
        // First beep
        Set_EXIO(EXIO_PIN8, High);
        delay(100);
        Set_EXIO(EXIO_PIN8, Low);
        delay(100);
        // Second beep
        Set_EXIO(EXIO_PIN8, High);
        delay(100);
        Set_EXIO(EXIO_PIN8, Low);
    }
}

// Event handler for brightness slider
static void brightness_slider_event_cb(lv_event_t *e)
{
    lv_obj_t *slider = lv_event_get_target(e);
    int32_t value = lv_slider_get_value(slider);
    
    // Update brightness
    Set_Backlight((uint8_t)value);
    LCD_Backlight = (uint8_t)value;
    
    // Update label
    lv_label_set_text_fmt(ui_BrightnessLabel, "Brightness: %d%%", (int)value);
}

// Event handler for buzzer switch
static void buzzer_switch_event_cb(lv_event_t *e)
{
    lv_obj_t * sw = lv_event_get_target(e);
    buzzer_mode = lv_obj_has_state(sw, LV_STATE_CHECKED) ? 1 : 0;
    const char *mode_text = buzzer_mode ? "Alert Mode" : "Off";
    lv_label_set_text_fmt(ui_BuzzerLabel, "Buzzer: %s", mode_text);
    printf("Buzzer mode: %s\n", mode_text);
}

// Update IP address when screen is shown
void update_ip_address(void)
{
    if (ui_IPLabel != NULL) {
        if (WiFi.status() == WL_CONNECTED) {
            String ip = WiFi.localIP().toString();
            lv_label_set_text(ui_IPLabel, ip.c_str());
        } else {
            lv_label_set_text(ui_IPLabel, "Not Connected");
        }
    }
}

// Event handler for back button (swipe up)
static void back_button_event_cb(lv_event_t *e)
{
    lv_scr_load_anim(ui_Screen1, LV_SCR_LOAD_ANIM_MOVE_TOP, 300, 0, false);
}

// Event handler for swipe up gesture - manual detection
static int16_t settings_swipe_start_x = 0;
static int16_t settings_swipe_start_y = 0;
static bool settings_swipe_in_progress = false;

static void swipe_up_event_cb(lv_event_t *e)
{
    lv_event_code_t code = lv_event_get_code(e);
    
    if (code == LV_EVENT_PRESSED) {
        lv_point_t point;
        lv_indev_get_point(lv_indev_get_act(), &point);
        settings_swipe_start_x = point.x;
        settings_swipe_start_y = point.y;
        settings_swipe_in_progress = true;
    }
    else if (code == LV_EVENT_RELEASED && settings_swipe_in_progress) {
        lv_point_t point;
        lv_indev_get_point(lv_indev_get_act(), &point);
        int16_t end_x = point.x;
        int16_t end_y = point.y;
        
        int16_t delta_x = end_x - settings_swipe_start_x;
        int16_t delta_y = end_y - settings_swipe_start_y;
        
        // Check for upward swipe (delta_y < -50 and mostly vertical)
        if (delta_y < -50 && abs(delta_y) > abs(delta_x)) {
            printf("SWIPE UP DETECTED - Returning to Main\n");
            lv_scr_load_anim(ui_Screen1, LV_SCR_LOAD_ANIM_MOVE_TOP, 300, 0, false);
        }
        
        settings_swipe_in_progress = false;
    }
}

void ui_Settings_screen_init(void)
{
    ui_Settings = lv_obj_create(NULL);
    lv_obj_clear_flag(ui_Settings, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_set_style_bg_color(ui_Settings, lv_color_hex(0x000000), 0);
    
    // Add swipe detection to background (won't interfere with child widgets)
    lv_obj_add_event_cb(ui_Settings, swipe_up_event_cb, LV_EVENT_PRESSED, NULL);
    lv_obj_add_event_cb(ui_Settings, swipe_up_event_cb, LV_EVENT_PRESSING, NULL);
    lv_obj_add_event_cb(ui_Settings, swipe_up_event_cb, LV_EVENT_RELEASED, NULL);
    
    // Update IP address when screen loads
    lv_obj_add_event_cb(ui_Settings, [](lv_event_t *e) { update_ip_address(); }, LV_EVENT_SCREEN_LOADED, NULL);
    
    printf("Settings swipe events registered\n");
    
    // Settings panel - circular for round display
    ui_SettingsPanel = lv_obj_create(ui_Settings);
    lv_obj_set_width(ui_SettingsPanel, 460);
    lv_obj_set_height(ui_SettingsPanel, 460);
    lv_obj_set_align(ui_SettingsPanel, LV_ALIGN_CENTER);
    lv_obj_clear_flag(ui_SettingsPanel, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_set_style_bg_color(ui_SettingsPanel, lv_color_hex(0x1A1A1A), 0);
    lv_obj_set_style_border_width(ui_SettingsPanel, 0, 0);
    lv_obj_set_style_radius(ui_SettingsPanel, 230, 0);  // Perfect circle (radius = width/2)
    
    // Add swipe detection to panel as well
    lv_obj_add_event_cb(ui_SettingsPanel, swipe_up_event_cb, LV_EVENT_PRESSED, NULL);
    lv_obj_add_event_cb(ui_SettingsPanel, swipe_up_event_cb, LV_EVENT_PRESSING, NULL);
    lv_obj_add_event_cb(ui_SettingsPanel, swipe_up_event_cb, LV_EVENT_RELEASED, NULL);
    
    // Title
    lv_obj_t *title = lv_label_create(ui_SettingsPanel);
    lv_label_set_text(title, "SETTINGS");  // All caps for emphasis
    lv_obj_set_style_text_color(title, lv_color_hex(0xFFFFFF), 0);
    lv_obj_set_x(title, 0);
    lv_obj_set_y(title, -150);
    lv_obj_set_align(title, LV_ALIGN_CENTER);
    
    // Brightness label
    ui_BrightnessLabel = lv_label_create(ui_SettingsPanel);
    lv_label_set_text_fmt(ui_BrightnessLabel, "Brightness: %d%%", LCD_Backlight);
    lv_obj_set_style_text_color(ui_BrightnessLabel, lv_color_hex(0xFFFFFF), 0);
    lv_obj_set_x(ui_BrightnessLabel, 0);
    lv_obj_set_y(ui_BrightnessLabel, -80);
    lv_obj_set_align(ui_BrightnessLabel, LV_ALIGN_CENTER);
    
    // Brightness slider
    ui_BrightnessSlider = lv_slider_create(ui_SettingsPanel);
    lv_slider_set_range(ui_BrightnessSlider, 10, 100);  // Min 10% to avoid completely dark screen
    lv_slider_set_value(ui_BrightnessSlider, LCD_Backlight, LV_ANIM_OFF);
    lv_obj_set_width(ui_BrightnessSlider, 300);
    lv_obj_set_height(ui_BrightnessSlider, 20);
    lv_obj_set_x(ui_BrightnessSlider, 0);
    lv_obj_set_y(ui_BrightnessSlider, -30);
    lv_obj_set_align(ui_BrightnessSlider, LV_ALIGN_CENTER);
    lv_obj_set_style_bg_color(ui_BrightnessSlider, lv_color_hex(0x404040), LV_PART_MAIN);
    lv_obj_set_style_bg_color(ui_BrightnessSlider, lv_color_hex(0x00A8FF), LV_PART_INDICATOR);
    lv_obj_set_style_bg_color(ui_BrightnessSlider, lv_color_hex(0xFFFFFF), LV_PART_KNOB);
    lv_obj_add_event_cb(ui_BrightnessSlider, brightness_slider_event_cb, LV_EVENT_VALUE_CHANGED, NULL);
    
    // Buzzer label
    ui_BuzzerLabel = lv_label_create(ui_SettingsPanel);
    lv_label_set_text(ui_BuzzerLabel, "Buzzer: Off");
    lv_obj_set_style_text_color(ui_BuzzerLabel, lv_color_hex(0xFFFFFF), 0);
    lv_obj_set_x(ui_BuzzerLabel, 0);
    lv_obj_set_y(ui_BuzzerLabel, 20);
    lv_obj_set_align(ui_BuzzerLabel, LV_ALIGN_CENTER);
    
    // Buzzer switch
    ui_BuzzerSwitch = lv_switch_create(ui_SettingsPanel);
    lv_obj_set_width(ui_BuzzerSwitch, 50);
    lv_obj_set_height(ui_BuzzerSwitch, 25);
    lv_obj_set_x(ui_BuzzerSwitch, 0);
    lv_obj_set_y(ui_BuzzerSwitch, 55);
    lv_obj_set_align(ui_BuzzerSwitch, LV_ALIGN_CENTER);
    lv_obj_set_style_bg_color(ui_BuzzerSwitch, lv_color_hex(0x404040), LV_PART_MAIN);
    lv_obj_set_style_bg_color(ui_BuzzerSwitch, lv_color_hex(0x00A8FF), LV_PART_INDICATOR | LV_STATE_CHECKED);
    lv_obj_add_event_cb(ui_BuzzerSwitch, buzzer_switch_event_cb, LV_EVENT_VALUE_CHANGED, NULL);
    
    // IP Address label title
    lv_obj_t *ip_title = lv_label_create(ui_SettingsPanel);
    lv_label_set_text(ip_title, "IP Address:");
    lv_obj_set_style_text_color(ip_title, lv_color_hex(0xFFFFFF), 0);
    lv_obj_set_x(ip_title, 0);
    lv_obj_set_y(ip_title, 100);
    lv_obj_set_align(ip_title, LV_ALIGN_CENTER);
    
    // IP Address value
    ui_IPLabel = lv_label_create(ui_SettingsPanel);
    lv_label_set_text(ui_IPLabel, "Checking...");
    lv_obj_set_style_text_color(ui_IPLabel, lv_color_hex(0x00FF00), 0);
    lv_obj_set_x(ui_IPLabel, 0);
    lv_obj_set_y(ui_IPLabel, 135);
    lv_obj_set_align(ui_IPLabel, LV_ALIGN_CENTER);
    
    // Instruction text
    lv_obj_t *instruction = lv_label_create(ui_SettingsPanel);
    lv_label_set_text(instruction, "Swipe up to return");
    lv_obj_set_style_text_color(instruction, lv_color_hex(0x808080), 0);
    lv_obj_set_x(instruction, 0);
    lv_obj_set_y(instruction, 165);
    lv_obj_set_align(instruction, LV_ALIGN_CENTER);
}
