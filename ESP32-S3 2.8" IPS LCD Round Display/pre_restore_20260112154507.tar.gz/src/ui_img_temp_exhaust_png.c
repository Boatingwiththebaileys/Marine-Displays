#include "ui.h"


// IMAGE DATA: assets/Temp_Exhaust.bin (RGB565 binary)
const char *ui_img_temp_exhaust_png = "S:/assets/Temp_Exhaust.bin";
