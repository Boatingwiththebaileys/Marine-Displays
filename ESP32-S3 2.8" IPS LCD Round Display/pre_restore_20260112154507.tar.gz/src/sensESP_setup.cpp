// ...existing code...

#include "gauge_config.h"
#include <Arduino.h>
#include <WiFi.h>
#include <WebServer.h>
#include <ESPmDNS.h>
#include <Preferences.h>
#include "sensESP_setup.h"
#include "signalk_config.h"
#include "gauge_config.h"
#include "screen_config_c_api.h"
#include <FS.h>
#include <SPIFFS.h>
#include <SD_MMC.h>

// ...existing code...

// Place fallback/error screen logic after all includes and config loads
extern "C" void show_fallback_error_screen_if_needed() {
    bool all_default = true;
    for (int s = 0; s < NUM_SCREENS && all_default; ++s) {
        for (int g = 0; g < 2 && all_default; ++g) {
            for (int p = 0; p < 5; ++p) {
                if (screen_configs[s].cal[g][p].angle != 0 || screen_configs[s].cal[g][p].value != 0.0f) {
                    all_default = false; break;
                }
            }
        }
    }
    if (all_default) {
        Serial.println("[ERROR] All screen configs are default/blank. Showing fallback error screen.");
        #ifdef LVGL_H
        lv_obj_t *scr = lv_scr_act();
        lv_obj_clean(scr);
        lv_obj_t *label = lv_label_create(scr);
        lv_label_set_text(label, "ERROR: No valid config loaded.\nCheck SD card or NVS.");
        lv_obj_align(label, LV_ALIGN_CENTER, 0, 0);
        #endif
    }
}

// ...existing code...

#include "gauge_config.h"


#include <Arduino.h>
#include <WiFi.h>
#include <WebServer.h>
#include <ESPmDNS.h>
#include <Preferences.h>
#include "sensESP_setup.h"
#include "signalk_config.h"
#include "gauge_config.h"
#include "screen_config_c_api.h"
#include <FS.h>
#include <SPIFFS.h>
#include <SD_MMC.h>

#include "nvs.h"
#include "nvs_flash.h"
#include <esp_err.h>
#include "esp_log.h"

static const char *TAG_SETUP = "sensESP_setup";

// Expose a small helper to dump loaded screen configs for debugging
void dump_screen_configs(void) {
    ESP_LOGI(TAG_SETUP, "Dumping %u screen_configs", (unsigned)(sizeof(screen_configs)/sizeof(screen_configs[0])));
    size_t total_screens = sizeof(screen_configs)/sizeof(screen_configs[0]);
    for (size_t s = 0; s < total_screens; ++s) {
        ESP_LOGI(TAG_SETUP, "Screen %u: icon_top='%s' icon_bottom='%s'", (unsigned)s,
                 screen_configs[s].icon_paths[0], screen_configs[s].icon_paths[1]);
        for (int g = 0; g < 2; ++g) {
            for (int z = 1; z <= 4; ++z) {
                ESP_LOGI(TAG_SETUP, "  S%u G%d Z%d: color='%s' transparent=%d min=%f max=%f",
                         (unsigned)s, g, z, screen_configs[s].color[g][z], screen_configs[s].transparent[g][z],
                         screen_configs[s].min[g][z], screen_configs[s].max[g][z]);
            }
        }
    }
}

// Minimal HTML style used by the configuration web pages
const String STYLE = R"rawliteral(
<style>
body{font-family:Arial,Helvetica,sans-serif;background:#fff;color:#111}
.container{max-width:900px;margin:0 auto;padding:12px}
.tab-btn{background:#f4f6fa;border:1px solid #d8e0ef;border-radius:4px;padding:8px 12px;cursor:pointer}
.tab-content{border:1px solid #e6e9f2;padding:12px;border-radius:6px;background:#fff}
input[type=number]{width:90px}
</style>
)rawliteral";

// Forward declaration for toggle test mode handler
void handle_toggle_test_mode();
void handle_test_gauge();
void handle_nvs_test();

WebServer config_server(80);
Preferences preferences;

String saved_ssid = "";
String saved_password = "";
String saved_signalk_ip = "";
uint16_t saved_signalk_port = 0;
// 10 SignalK paths: [screen][gauge] => idx = s*2+g
String signalk_paths[NUM_SCREENS * 2];
// Namespaces used for Preferences / NVS
const char* SETTINGS_NAMESPACE = "settings";
const char* PREF_NAMESPACE = "gaugeconfig";

// Ensure ScreenConfig/screen_configs symbol visible
#include "screen_config_c_api.h"

void save_preferences() {
    Serial.println("[DEBUG] Saving preferences...");
    preferences.end();
    if (!preferences.begin(SETTINGS_NAMESPACE, false)) {
        Serial.println("[ERROR] preferences.begin failed for settings namespace");
    } else {
        preferences.putString("ssid", saved_ssid);
        preferences.putString("password", saved_password);
        preferences.putString("signalk_ip", saved_signalk_ip);
        preferences.putUShort("signalk_port", saved_signalk_port);
        for (int i = 0; i < NUM_SCREENS * 2; ++i) {
            String key = String("skpath_") + i;
            preferences.putString(key.c_str(), signalk_paths[i]);
        }
        preferences.end();
    }

    // Try to save per-screen blobs via NVS
    nvs_handle_t nvs_handle;
    esp_err_t nvs_err = nvs_open(PREF_NAMESPACE, NVS_READWRITE, &nvs_handle);
    bool any_nvs_ok = false;
    bool nvs_invalid_length_detected = false;
    const size_t CHUNK_SIZE = 128;
    if (nvs_err == ESP_OK) {
        for (int s = 0; s < NUM_SCREENS; ++s) {
            // copy runtime calibration into screen_configs
            for (int g = 0; g < 2; ++g) for (int p = 0; p < 5; ++p) screen_configs[s].cal[g][p] = gauge_cal[s][g][p];
            char key[32];
            snprintf(key, sizeof(key), "screen%d", s);
            esp_err_t err = nvs_set_blob(nvs_handle, key, &screen_configs[s], sizeof(ScreenConfig));
            Serial.printf("[NVS SAVE] nvs_set_blob('%s', size=%u) -> %d\n", key, (unsigned)sizeof(ScreenConfig), err);
            if (err != ESP_OK) {
                esp_err_t erase_err = nvs_erase_key(nvs_handle, key);
                Serial.printf("[NVS SAVE] nvs_erase_key('%s') -> %d\n", key, erase_err);
                if (erase_err == ESP_OK) {
                    err = nvs_set_blob(nvs_handle, key, &screen_configs[s], sizeof(ScreenConfig));
                    Serial.printf("[NVS SAVE] Retry nvs_set_blob('%s') -> %d\n", key, err);
                }
            }
            if (err == ESP_OK) {
                any_nvs_ok = true;
                continue;
            }
            if (err == ESP_ERR_NVS_INVALID_LENGTH) {
                nvs_invalid_length_detected = true;
            }
            // chunked fallback
            size_t total = sizeof(ScreenConfig);
            int parts = (total + CHUNK_SIZE - 1) / CHUNK_SIZE;
            bool parts_ok = true;
            for (int part = 0; part < parts; ++part) {
                snprintf(key, sizeof(key), "screen%d.part%d", s, part);
                size_t part_sz = ((part + 1) * CHUNK_SIZE > total) ? (total - part * CHUNK_SIZE) : CHUNK_SIZE;
                esp_err_t perr = nvs_set_blob(nvs_handle, key, ((uint8_t *)&screen_configs[s]) + part * CHUNK_SIZE, part_sz);
                Serial.printf("[NVS SAVE] nvs_set_blob('%s', size=%u) -> %d\n", key, (unsigned)part_sz, perr);
                if (perr != ESP_OK) { parts_ok = false; break; }
            }
            if (parts_ok) {
                any_nvs_ok = true;
                Serial.printf("[NVS SAVE] Chunked write succeeded for screen%d (%d parts)\n", s, parts);
            }
        }
        nvs_commit(nvs_handle);
        nvs_close(nvs_handle);
    } else {
        Serial.printf("[ERROR] nvs_open failed: %d\n", nvs_err);
    }

    // If we detected systematic NVS invalid-length errors, attempt a repair
    if (nvs_invalid_length_detected) {
        const char *repair_marker = "/config/.nvs_repaired";
        if (!SD_MMC.exists(repair_marker)) {
            Serial.println("[NVS REPAIR] Detected invalid-length errors; attempting NVS repair (erase+init)");
            // Backup settings to SD
            if (!SD_MMC.exists("/config")) SD_MMC.mkdir("/config");
            File bst = SD_MMC.open("/config/nvs_backup_settings.txt", FILE_WRITE);
            if (bst) {
                bst.println(saved_ssid);
                bst.println(saved_password);
                bst.println(saved_signalk_ip);
                bst.println(String(saved_signalk_port));
                for (int i = 0; i < NUM_SCREENS * 2; ++i) bst.println(signalk_paths[i]);
                bst.close();
                Serial.println("[NVS REPAIR] Wrote /config/nvs_backup_settings.txt");
            } else {
                Serial.println("[NVS REPAIR] Failed to write settings backup to SD");
            }
            // Backup screen configs
            File bsf = SD_MMC.open("/config/nvs_backup_screens.bin", FILE_WRITE);
            if (bsf) {
                bsf.write((const uint8_t *)screen_configs, sizeof(ScreenConfig) * NUM_SCREENS);
                bsf.close();
                Serial.println("[NVS REPAIR] Wrote /config/nvs_backup_screens.bin");
            } else {
                Serial.println("[NVS REPAIR] Failed to write screens backup to SD");
            }

            // Erase and re-init NVS
            esp_err_t erase_res = nvs_flash_erase();
            Serial.printf("[NVS REPAIR] nvs_flash_erase() -> %d\n", erase_res);
            esp_err_t init_res = nvs_flash_init();
            Serial.printf("[NVS REPAIR] nvs_flash_init() -> %d\n", init_res);

            // Retry writing Preferences and NVS blobs once
            if (init_res == ESP_OK) {
                // Restore preferences (SSID/password etc)
                if (preferences.begin(SETTINGS_NAMESPACE, false)) {
                    preferences.putString("ssid", saved_ssid);
                    preferences.putString("password", saved_password);
                    preferences.putString("signalk_ip", saved_signalk_ip);
                    preferences.putUShort("signalk_port", saved_signalk_port);
                    for (int i = 0; i < NUM_SCREENS * 2; ++i) {
                        String key = String("skpath_") + i;
                        preferences.putString(key.c_str(), signalk_paths[i]);
                    }
                    preferences.end();
                }

                nvs_handle_t nh2;
                if (nvs_open(PREF_NAMESPACE, NVS_READWRITE, &nh2) == ESP_OK) {
                    bool any_ok2 = false;
                    for (int s = 0; s < NUM_SCREENS; ++s) {
                        char key[32];
                        snprintf(key, sizeof(key), "screen%d", s);
                        esp_err_t r2 = nvs_set_blob(nh2, key, &screen_configs[s], sizeof(ScreenConfig));
                        Serial.printf("[NVS REPAIR] Retry nvs_set_blob('%s') -> %d\n", key, r2);
                        if (r2 == ESP_OK) any_ok2 = true;
                    }
                    nvs_commit(nh2);
                    nvs_close(nh2);
                    // create marker file so we don't repeat erase
                    File mf = SD_MMC.open(repair_marker, FILE_WRITE);
                    if (mf) { mf.print("1"); mf.close(); Serial.println("[NVS REPAIR] Marker written"); }
                    if (any_ok2) {
                        Serial.println("[NVS REPAIR] Repair appeared successful; proceeding");
                    } else {
                        Serial.println("[NVS REPAIR] Repair did not restore NVS blob writes");
                    }
                } else {
                    Serial.println("[NVS REPAIR] nvs_open failed after reinit");
                }
            }
        } else {
            Serial.println("[NVS REPAIR] Repair marker present; skipping erase to avoid data loss");
        }
    }

    // Debug: print signalk_paths content before SD/NVS operations
    Serial.println("[DEBUG] signalk_paths before saving:");
    for (int i = 0; i < NUM_SCREENS * 2; ++i) {
        Serial.printf("[DEBUG] signalk_paths[%d] = '%s'\n", i, signalk_paths[i].c_str());
    }

    if (!any_nvs_ok) {
        Serial.println("[SD SAVE] NVS blob writes failed; saving screen configs to SD as fallback...");
        if (!SD_MMC.exists("/config")) SD_MMC.mkdir("/config");
        for (int s = 0; s < NUM_SCREENS; ++s) {
            char sdpath[64];
            snprintf(sdpath, sizeof(sdpath), "/config/screen%d.bin", s);
            File f = SD_MMC.open(sdpath, FILE_WRITE);
            if (!f) { Serial.printf("[SD SAVE] Failed to open '%s'\n", sdpath); continue; }
            size_t written = f.write((const uint8_t *)&screen_configs[s], sizeof(ScreenConfig));
            f.close();
            Serial.printf("[SD SAVE] Wrote '%s' -> %u bytes\n", sdpath, (unsigned)written);
        }
    }

    // Verify settings namespace saved correctly (read back keys)
    if (preferences.begin(SETTINGS_NAMESPACE, true)) {
        Serial.println("[DEBUG] Verifying saved SignalK path keys in SETTINGS_NAMESPACE:");
        for (int i = 0; i < NUM_SCREENS * 2; ++i) {
            String key = String("skpath_") + i;
            String v = preferences.getString(key.c_str(), "<missing>");
            Serial.printf("[DEBUG] prefs[%s] = '%s'\n", key.c_str(), v.c_str());
        }
        preferences.end();
    } else {
        Serial.println("[DEBUG] preferences.begin(SETTINGS_NAMESPACE, true) failed for verification");
    }
    // Also print saved SSID/password from Preferences to verify
    if (preferences.begin(SETTINGS_NAMESPACE, true)) {

    // Always write SignalK paths to SD as a fallback in case Preferences/NVS fails
    if (!SD_MMC.exists("/config")) SD_MMC.mkdir("/config");
    File spf = SD_MMC.open("/config/signalk_paths.txt", FILE_WRITE);
    if (spf) {
        for (int i = 0; i < NUM_SCREENS * 2; ++i) {
            spf.println(signalk_paths[i]);
        }
        spf.close();
        Serial.println("[SD SAVE] Wrote /config/signalk_paths.txt");
    } else {
        Serial.println("[SD SAVE] Failed to open /config/signalk_paths.txt for writing");
    }
        String vs = preferences.getString("ssid", "<missing>");
        String vp = preferences.getString("password", "<missing>");
        Serial.printf("[DEBUG] prefs saved SSID='%s' PASSWORD='%s'\n", vs.c_str(), vp.c_str());
        preferences.end();
    }
}

// Load preferences and screen configs from NVS or SD fallback
void load_preferences() {
    // Load settings (WiFi, Signalk) from SETTINGS_NAMESPACE
    preferences.end();
    if (preferences.begin(SETTINGS_NAMESPACE, true)) {
        saved_ssid = preferences.getString("ssid", "");
        saved_password = preferences.getString("password", "");
        saved_signalk_ip = preferences.getString("signalk_ip", "");
        saved_signalk_port = preferences.getUShort("signalk_port", 0);
        for (int i = 0; i < NUM_SCREENS * 2; ++i) {
            String key = String("skpath_") + i;
            signalk_paths[i] = preferences.getString(key.c_str(), "");
        }
        preferences.end();
    }
    // If SignalK paths are empty in Preferences, try SD fallback file
    bool any_path_set = false;
    for (int i = 0; i < NUM_SCREENS * 2; ++i) if (signalk_paths[i].length() > 0) { any_path_set = true; break; }
    if (!any_path_set) {
        const char *spfpath = "/config/signalk_paths.txt";
        if (SD_MMC.exists(spfpath)) {
            File spf = SD_MMC.open(spfpath, FILE_READ);
            if (spf) {
                Serial.println("[SD LOAD] Loading SignalK paths from /config/signalk_paths.txt");
                int idx = 0;
                while (spf.available() && idx < NUM_SCREENS * 2) {
                    String line = spf.readStringUntil('\n');
                    line.trim();
                    signalk_paths[idx++] = line;
                }
                spf.close();
            }
        }
    }
    Serial.printf("[DEBUG] Loaded settings: ssid='%s' password='%s' signalk_ip='%s' port=%u\n",
                  saved_ssid.c_str(), saved_password.c_str(), saved_signalk_ip.c_str(), saved_signalk_port);

    // Initialize defaults
    for (int s = 0; s < NUM_SCREENS; ++s) {
        // zero screen_configs so defaults are predictable
        memset(&screen_configs[s], 0, sizeof(ScreenConfig));
    }

    // Try to load screen configs from NVS (PREF_NAMESPACE)
    nvs_handle_t nvs_handle;
    esp_err_t nvs_err = nvs_open(PREF_NAMESPACE, NVS_READONLY, &nvs_handle);
    const size_t CHUNK_SIZE = 128;
    if (nvs_err == ESP_OK) {
        for (int s = 0; s < NUM_SCREENS; ++s) {
            char key[32];
            snprintf(key, sizeof(key), "screen%d", s);
            ScreenConfig tmp;
            size_t required = sizeof(ScreenConfig);
            esp_err_t err = nvs_get_blob(nvs_handle, key, &tmp, &required);
            if (err == ESP_OK && required == sizeof(ScreenConfig)) {
                memcpy(&screen_configs[s], &tmp, sizeof(ScreenConfig));
                continue;
            }
            // try chunked parts
            int parts = (sizeof(ScreenConfig) + CHUNK_SIZE - 1) / CHUNK_SIZE;
            bool got_parts = true;
            for (int part = 0; part < parts; ++part) {
                snprintf(key, sizeof(key), "screen%d.part%d", s, part);
                size_t part_sz = ((part + 1) * CHUNK_SIZE > sizeof(ScreenConfig)) ? (sizeof(ScreenConfig) - part * CHUNK_SIZE) : CHUNK_SIZE;
                esp_err_t perr = nvs_get_blob(nvs_handle, key, ((uint8_t *)&screen_configs[s]) + part * CHUNK_SIZE, &part_sz);
                if (perr != ESP_OK) {
                    got_parts = false;
                    break;
                }
            }
            if (got_parts) continue;
        }
        nvs_close(nvs_handle);
    }

    // If any screen config is still default, always restore from SD if available
    bool restored_from_sd = false;
    for (int s = 0; s < NUM_SCREENS; ++s) {
        bool is_default = true;
        for (int g = 0; g < 2 && is_default; ++g) {
            for (int p = 0; p < 5; ++p) {
                if (screen_configs[s].cal[g][p].angle != 0 || screen_configs[s].cal[g][p].value != 0.0f) {
                    is_default = false; break;
                }
            }
        }
        if (is_default) {
            char sdpath[64];
            snprintf(sdpath, sizeof(sdpath), "/config/screen%d.bin", s);
            if (SD_MMC.exists(sdpath)) {
                File f = SD_MMC.open(sdpath, FILE_READ);
                if (f) {
                    size_t got = f.read((uint8_t *)&screen_configs[s], sizeof(ScreenConfig));
                    Serial.printf("[SD LOAD] Read '%s' -> %u bytes (expected %u)\n", sdpath, (unsigned)got, (unsigned)sizeof(ScreenConfig));
                    f.close();
                    // Validate loaded config
                    bool valid = true;
                    for (int g = 0; g < 2 && valid; ++g) {
                        for (int p = 0; p < 5; ++p) {
                            if (screen_configs[s].cal[g][p].angle < 0 || screen_configs[s].cal[g][p].angle > 360) {
                                valid = false; break;
                            }
                        }
                    }
                    if (!valid) {
                        Serial.printf("[CONFIG ERROR] SD config for screen %d invalid, restoring defaults\n", s);
                        memset(&screen_configs[s], 0, sizeof(ScreenConfig));
                    } else {
                        restored_from_sd = true;
                    }
                } else {
                    Serial.printf("[SD LOAD] Failed to open '%s', restoring defaults for screen %d\n", sdpath, s);
                    memset(&screen_configs[s], 0, sizeof(ScreenConfig));
                }
            } else {
                Serial.printf("[CONFIG ERROR] No SD config for screen %d, restoring defaults\n", s);
                memset(&screen_configs[s], 0, sizeof(ScreenConfig));
            }
        }
    }
    if (restored_from_sd) {
        Serial.println("[CONFIG RESTORE] Screen configs restored from SD after NVS was blank/default.");
    }

    // Copy loaded calibration into gauge_cal for runtime use
    // Debug: dump raw screen_configs contents (strings + small hex preview) to help diagnose missing icon paths
    for (int si = 0; si < NUM_SCREENS; ++si) {
        ESP_LOGI(TAG_SETUP, "[DUMP SC] Screen %d: icon_top='%s' icon_bottom='%s'", si,
                 screen_configs[si].icon_paths[0], screen_configs[si].icon_paths[1]);
        // Print small hex preview of the first 64 bytes
        const uint8_t *bytes = (const uint8_t *)&screen_configs[si];
        char hbuf[3*17];
        for (int i = 0; i < 16; ++i) {
            snprintf(&hbuf[i*3], 4, "%02X ", bytes[i]);
        }
        hbuf[16*3-1] = '\0';
        ESP_LOGD(TAG_SETUP, "[DUMP SC] raw[0..15]=%s", hbuf);
    }
    for (int s = 0; s < NUM_SCREENS; ++s) {
        for (int g = 0; g < 2; ++g) {
            for (int p = 0; p < 5; ++p) {
                gauge_cal[s][g][p] = screen_configs[s].cal[g][p];
            }
        }
    }

    // No automatic default icon set; keep blank unless user selects one via UI
}

void handle_gauges_page() {
    // --- Scan SD card for available image files (PNG, BIN, JPG, BMP, GIF) ---
    std::vector<String> iconFiles;
    {
        File root = SD_MMC.open("/assets");
        if (root && root.isDirectory()) {
            File file = root.openNextFile();
            while (file) {
                String fname = file.name();
                Serial.printf("[ICON SCAN] Found file: %s\n", fname.c_str());
                // Exclude macOS resource fork files (._ prefix)
                if (fname.startsWith("._")) {
                    file = root.openNextFile();
                    continue;
                }
                fname.toLowerCase();
                if ((fname.endsWith(".png") || fname.endsWith(".bin") || fname.endsWith(".jpg") || fname.endsWith(".bmp") || fname.endsWith(".gif")) && !fname.startsWith("_")) {
                    // Always add /assets/ prefix if not present
                    String fullPath = fname;
                    if (!fname.startsWith("/assets/")) {
                        fullPath = "/assets/" + fname;
                    }
                    iconFiles.push_back(String("S:/") + fullPath);
                }
                file = root.openNextFile();
            }
        }
    }
    // --- End SD scan ---
    // Reload all config from NVS to ensure UI is up-to-date
    load_preferences();
    Serial.println("[DEBUG] handle_gauges_page() - gauge_cal values sent to HTML:");
    for (int s = 0; s < NUM_SCREENS; ++s) {
        for (int g = 0; g < 2; ++g) {
            for (int p = 0; p < 5; ++p) {
                Serial.printf("[DEBUG] gauge_cal[%d][%d][%d]: angle=%d value=%.2f\n", s, g, p, gauge_cal[s][g][p].angle, gauge_cal[s][g][p].value);
            }
        }
    }
    String html = "<!DOCTYPE html><html><head>";
    html += STYLE;
    html += "<title>Gauge Calibration</title></head><body><div class='container'>";
    extern bool test_mode;
    html += "<h2>Gauge Calibration</h2>";
    html += "<form method='POST' action='/toggle-test-mode' style='margin-bottom:16px;text-align:center;'>";
    html += "<input type='hidden' name='toggle' value='1'>";
    html += "<button type='submit' style='padding:8px 16px;font-size:1em;'>";
    html += (test_mode ? "Disable Setup Mode" : "Enable Setup Mode");
    html += "</button> ";
    html += "<span style='font-weight:bold;color:";
    html += (test_mode ? "#388e3c;'>SETUP MODE ON" : "#b71c1c;'>SETUP MODE OFF");
    html += "</span></form>";
        // --- Scan SD card for available image files (PNG, BIN, JPG, BMP, GIF) ---
        // ...existing code...
        // --- End SD scan ---
    // Calibration form start
    html += "<form id='calibrationForm' method='POST' action='/save-gauges'>";
    // Tab bar
    html += "<div style='margin-bottom:16px; text-align:center;'>";
    for (int s = 0; s < NUM_SCREENS; ++s) {
        html += "<button type='button' class='tab-btn' id='tabbtn_" + String(s) + "' onclick='showScreenTab(" + String(s) + ")' style='margin:0 4px; padding:8px 16px; font-size:1em;'>Screen " + String(s+1) + "</button>";
    }
    html += "</div>";
    // Tab content
    for (int s = 0; s < NUM_SCREENS; ++s) {
        html += "<div class='tab-content' id='tabcontent_" + String(s) + "' style='display:" + (s==0?"block":"none") + ";'>";
        html += "<h3>Screen " + String(s+1) + "</h3>";
        for (int g = 0; g < 2; ++g) {
            int idx = s * 2 + g;
            html += "<b>" + String(g == 0 ? "Top Gauge" : "Bottom Gauge") + "</b>";
            // Icon file dropdown
            String savedIcon = String(screen_configs[s].icon_paths[g]);
            String savedIconNorm = savedIcon;
            savedIconNorm.toLowerCase();
            savedIconNorm.replace("S://", "S:/");
            while (savedIconNorm.indexOf("//") != -1) savedIconNorm.replace("//", "/");
            html += "<div style='margin-bottom:8px;'><label>Icon: <select name='icon_" + String(s) + "_" + String(g) + "'>";
            html += "<option value=''";
            if (savedIcon.length() == 0) html += " selected='selected'";
            html += ">None</option>";
            for (const auto& icon : iconFiles) {
                String iconNorm = icon;
                iconNorm.toLowerCase();
                iconNorm.replace("S://", "S:/");
                while (iconNorm.indexOf("//") != -1) iconNorm.replace("//", "/");
                html += "<option value='" + icon + "'";
                if (iconNorm == savedIconNorm && savedIcon.length() > 0) html += " selected='selected'";
                html += ">" + icon + "</option>";
            }
            html += "</select></label></div>";
            html += "<div style='margin-bottom:8px;'>";
            for (int i = 1; i <= 4; ++i) {
                float minVal = screen_configs[s].min[g][i];
                float maxVal = screen_configs[s].max[g][i];
                String colorVal = String(screen_configs[s].color[g][i]);
                bool transVal = screen_configs[s].transparent[g][i] != 0;
                html += "<div style='margin-bottom:4px;'>";
                html += "<label>Min " + String(i) + ": <input name='mnv" + String(s) + String(g) + String(i) + "' type='number' step='any' value='" + String(minVal) + "'></label> ";
                html += "<label>Max " + String(i) + ": <input name='mxv" + String(s) + String(g) + String(i) + "' type='number' step='any' value='" + String(maxVal) + "'></label> ";
                html += "<label>Color " + String(i) + ": <input name='clr" + String(s) + String(g) + String(i) + "' type='color' value='" + colorVal + "'></label> ";
                html += "<label>Transparent <input name='trn" + String(s) + String(g) + String(i) + "' type='checkbox'";
                if (transVal) html += " checked";
                html += "></label>";
                html += "</div>";
            }
            html += "</div>";
            html += "<div style='margin-bottom:8px;'><label>SignalK Path: <input name='skpath_" + String(s) + "_" + String(g) + "' type='text' value='" + signalk_paths[idx] + "' style='width:80%'></label></div>";
            html += "<table class='table'><tr><th>Point</th><th>Angle</th><th>Value</th><th>Test</th></tr>";
            for (int p = 0; p < 5; ++p) {
                html += "<tr><td>" + String(p+1) + "</td>";
                html += "<td><input name='" + String("angle_") + s + "_" + g + "_" + p + "' type='number' value='" + String(gauge_cal[s][g][p].angle) + "'></td>";
                html += "<td><input name='" + String("value_") + s + "_" + g + "_" + p + "' type='number' step='any' value='" + String(gauge_cal[s][g][p].value) + "'></td>";
                html += "<td id='testbtn_" + String(s) + "_" + g + "_" + p + "'></td></tr>";
            }
            html += "</table>";
        }
        html += "</div>";
    }
    // Tab JS and Save button (ensure inside form)
    html += "<div style='text-align:center; margin-top:16px;'><input type='submit' value='Save & Reboot' style='padding:10px 24px; font-size:1.1em;'></div>";
    html += "</form>";
    // Now add the test buttons outside the main form
    for (int s = 0; s < NUM_SCREENS; ++s) {
        for (int g = 0; g < 2; ++g) {
            for (int p = 0; p < 5; ++p) {
                html += "<form style='display:none;' id='testform_" + String(s) + "_" + String(g) + "_" + String(p) + "' method='POST' action='/test-gauge'>";
                html += "<input type='hidden' name='screen' value='" + String(s) + "'>";
                html += "<input type='hidden' name='gauge' value='" + String(g) + "'>";
                html += "<input type='hidden' name='point' value='" + String(p) + "'>";
                html += "<input type='hidden' name='angle' id='testangle_" + String(s) + "_" + String(g) + "_" + String(p) + "' value=''>";
                html += "</form>";
            }
        }
    }
    html += "<script>function showScreenTab(idx){\n";
    html += "  for(var s=0;s<" + String(NUM_SCREENS) + ";++s){\n";
    html += "    document.getElementById('tabcontent_'+s).style.display=(s==idx?'block':'none');\n";
    html += "    var btn=document.getElementById('tabbtn_'+s);\n";
    html += "    if(btn)btn.style.background=(s==idx?'#e3eaf6':'#f4f6fa');\n";
    html += "  }\n";
    html += "}\n";
    html += "document.addEventListener('DOMContentLoaded',function(){\n";
    html += "  var testMode = " + String(test_mode ? "true" : "false") + ";\n";
    html += "  for (var s = 0; s < " + String(NUM_SCREENS) + "; ++s) {\n";
    html += "    for (var g = 0; g < 2; ++g) {\n";
    html += "      for (var p = 0; p < 5; ++p) {\n";
    html += "        var btn = document.createElement('button');\n";
    html += "        btn.type = 'button';\n";
    html += "        btn.innerText = 'Test';\n";
    html += "        btn.disabled = !testMode;\n";
    html += "        btn.onclick = (function(ss,gg,pp){ return function(){\n";
    html += "          var angleInput = document.querySelector('input[name=\"angle_'+ss+'_'+gg+'_'+pp+'\"]');\n";
    html += "          var testAngle = document.getElementById('testangle_'+ss+'_'+gg+'_'+pp);\n";
    html += "          if(angleInput && testAngle){ testAngle.value = angleInput.value; }\n";
    html += "          document.getElementById('testform_'+ss+'_'+gg+'_'+pp).submit();\n";
    html += "        }; })(s,g,p);\n";
    html += "        document.getElementById('testbtn_'+s+'_'+g+'_'+p).appendChild(btn);\n";
    html += "      }\n";
    html += "    }\n";
    html += "  }\n";
    html += "});</script>";
    html += "<p style='text-align:center;'><a href='/'>Back</a></p>";
    html += "</div></body></html>";
    config_server.send(200, "text/html", html);
}

void handle_save_gauges() {
            // Debug: print all POSTed keys and values
            Serial.println("[DEBUG] POSTED FORM KEYS AND VALUES:");
            int nArgs = config_server.args();
            for (int i = 0; i < nArgs; ++i) {
                String key = config_server.argName(i);
                String val = config_server.arg(i);
                Serial.printf("[POST] %s = '%s'\n", key.c_str(), val.c_str());
            }
        Serial.println("[DEBUG] handle_save_gauges() POST values and gauge_cal after POST:");
        for (int s = 0; s < NUM_SCREENS; ++s) {
            for (int g = 0; g < 2; ++g) {
                for (int p = 0; p < 5; ++p) {
                    String angleKey = "angle_" + String(s) + "_" + String(g) + "_" + String(p);
                    String valueKey = "value_" + String(s) + "_" + String(g) + "_" + String(p);
                    Serial.printf("[DEBUG] POST: %s='%s', %s='%s'\n", angleKey.c_str(), config_server.arg(angleKey).c_str(), valueKey.c_str(), config_server.arg(valueKey).c_str());
                    Serial.printf("[DEBUG] gauge_cal[%d][%d][%d]: angle=%d value=%.2f\n", s, g, p, gauge_cal[s][g][p].angle, gauge_cal[s][g][p].value);
                }
            }
        }
        Serial.println("[DEBUG] handle_gauges_page() - gauge_cal values sent to GUI:");
        for (int s = 0; s < NUM_SCREENS; ++s) {
            for (int g = 0; g < 2; ++g) {
                for (int p = 0; p < 5; ++p) {
                    Serial.printf("[DEBUG] gauge_cal[%d][%d][%d]: angle=%d value=%.2f\n", s, g, p, gauge_cal[s][g][p].angle, gauge_cal[s][g][p].value);
                }
            }
        }
    Serial.println("[DEBUG] handle_save_gauges() called");
    if (config_server.method() == HTTP_POST) {
        for (int s = 0; s < NUM_SCREENS; ++s) {
            for (int g = 0; g < 2; ++g) {
                int idx = s * 2 + g;
                // Save SignalK path
                String skpathKey = "skpath_" + String(s) + "_" + String(g);
                if (config_server.hasArg(skpathKey)) {
                    signalk_paths[idx] = config_server.arg(skpathKey);
                }
                // Save icon selection
                String iconKey = "icon_" + String(s) + "_" + String(g);
                String iconValue = config_server.arg(iconKey);
                iconValue.replace("S://", "S:/");
                while (iconValue.indexOf("//") != -1) iconValue.replace("//", "/");
                strncpy(screen_configs[s].icon_paths[g], iconValue.c_str(), 127);
                screen_configs[s].icon_paths[g][127] = '\0';
                for (int i = 1; i <= 4; ++i) {
                    String minKey = "mnv" + String(s) + String(g) + String(i);
                    String maxKey = "mxv" + String(s) + String(g) + String(i);
                    String colorKey = "clr" + String(s) + String(g) + String(i);
                    String transKey = "trn" + String(s) + String(g) + String(i);
                    screen_configs[s].min[g][i] = config_server.arg(minKey).toFloat();
                    screen_configs[s].max[g][i] = config_server.arg(maxKey).toFloat();
                    strncpy(screen_configs[s].color[g][i], config_server.arg(colorKey).c_str(), 7);
                    screen_configs[s].color[g][i][7] = '\0';
                    screen_configs[s].transparent[g][i] = config_server.hasArg(transKey) ? 1 : 0;
                }
                for (int p = 0; p < 5; ++p) {
                    String angleKey = "angle_" + String(s) + "_" + String(g) + "_" + String(p);
                    String valueKey = "value_" + String(s) + "_" + String(g) + "_" + String(p);
                    String angleStr = config_server.arg(angleKey);
                    String valueStr = config_server.arg(valueKey);
                    Serial.printf("[DEBUG] POST: %s='%s', %s='%s'\n", angleKey.c_str(), angleStr.c_str(), valueKey.c_str(), valueStr.c_str());
                    gauge_cal[s][g][p].angle = angleStr.toInt();
                    gauge_cal[s][g][p].value = valueStr.toFloat();
                }
            }
        }
        // Print updated gauge_cal values before saving
        Serial.println("[DEBUG] gauge_cal values after POST:");
        for (int s = 0; s < NUM_SCREENS; ++s) {
            for (int g = 0; g < 2; ++g) {
                for (int p = 0; p < 5; ++p) {
                    Serial.printf("[DEBUG] gauge_cal[%d][%d][%d]: angle=%d value=%.2f\n", s, g, p, gauge_cal[s][g][p].angle, gauge_cal[s][g][p].value);
                }
            }
        }
        save_preferences();
        // NVS key enumeration debug (after all saves, before reboot)
        {
            nvs_handle_t nvs_enum_handle;
            esp_err_t nvs_enum_err = nvs_open(PREF_NAMESPACE, NVS_READONLY, &nvs_enum_handle);
            if (nvs_enum_err == ESP_OK) {
                Serial.println("[NVS ENUM] Listing all keys in 'gaugeconfig' namespace after icon/zone save:");
                nvs_iterator_t it = NULL;
                esp_err_t enum_find_err = nvs_entry_find(NULL, PREF_NAMESPACE, NVS_TYPE_ANY, &it);
                while (enum_find_err == ESP_OK && it != NULL) {
                    nvs_entry_info_t info;
                    nvs_entry_info(it, &info);
                    Serial.printf("[NVS ENUM] key: %s, type: %d\n", info.key, info.type);
                    enum_find_err = nvs_entry_next(&it);
                }
                Serial.println("[NVS ENUM] End of key list.");
                nvs_close(nvs_enum_handle);
            } else {
                Serial.printf("[NVS ENUM] nvs_open failed: %d\n", nvs_enum_err);
            }
        }
        String html = "<html><head>";
        html += STYLE;
        html += "<title>Saved</title></head><body><div class='container'>";
        html += "<h2>Gauge calibration saved.<br>Rebooting...</h2>";
        config_server.send(200, "text/html", html);
        delay(1000);
        ESP.restart();
    } else {
        config_server.send(405, "text/plain", "Method Not Allowed");
    }
}

void handle_root() {
    String html = "<html><head>";
    html += STYLE;
    html += "<title>ESP32 Gauge Config</title></head><body><div class='container'>";
    html += "<h1>ESP32 Gauge Config</h1>";
    html += "<div class='status'>Status: " + String(WiFi.isConnected() ? "Connected" : "AP Mode") + "<br>IP: " + WiFi.localIP().toString() + "</div>";
    html += "<p style='text-align:center;'><a href='/network'>Network Setup</a> | <a href='/gauges'>Gauge Calibration</a></p>";
    html += "</div></body></html>";
    config_server.send(200, "text/html", html);
}

void handle_network_page() {
    String html = "<html><head>";
    html += STYLE;
    html += "<title>Network Setup</title></head><body><div class='container'>";
    html += "<h2>Network Setup</h2>";
    html += "<form method='POST' action='/save-wifi'>";
    html += "<label>SSID:<input name='ssid' type='text' value='" + saved_ssid + "'></label>";
    html += "<label>Password:<input name='password' type='password' value='" + saved_password + "'></label>";
    html += "<label>SignalK Server:<input name='signalk_ip' type='text' value='" + saved_signalk_ip + "'></label>";
    html += "<label>SignalK Port:<input name='signalk_port' type='number' value='" + String(saved_signalk_port) + "'></label>";
    html += "<button type='submit' style='background:#2a4d7a;color:#fff;border:none;border-radius:5px;padding:10px;font-size:1em;cursor:pointer;'>Save & Reboot</button>";
    html += "</form>";
    html += "<p style='text-align:center;'><a href='/'>Back</a></p>";
    html += "</div></body></html>";
    config_server.send(200, "text/html", html);
}


void handle_save_wifi() {
    if (config_server.method() == HTTP_POST) {
        saved_ssid = config_server.arg("ssid");
        saved_password = config_server.arg("password");
        saved_signalk_ip = config_server.arg("signalk_ip");
        saved_signalk_port = config_server.arg("signalk_port").toInt();
        save_preferences();
        Serial.println("[WiFi Config] SSID: " + saved_ssid);
        Serial.println("[WiFi Config] Password: " + saved_password);
        Serial.println("[WiFi Config] SignalK IP: " + saved_signalk_ip);
        Serial.print("[WiFi Config] SignalK Port: ");
        Serial.println(saved_signalk_port);
        String html = "<html><head>";
        html += STYLE;
        html += "<title>Saved</title></head><body><div class='container'>";
        html += "<h2>Settings saved.<br>Rebooting...</h2>";
        html += "</div></body></html>";
        config_server.send(200, "text/html", html);
        delay(1000);
        ESP.restart();
    } else {
        config_server.send(405, "text/plain", "Method Not Allowed");
    }
}


void setup_sensESP() {
    Serial.begin(115200);
    delay(100);
    Serial.printf("Flash size (ESP.getFlashChipSize()): %u bytes\n", ESP.getFlashChipSize());
    if (!SPIFFS.begin(true)) {
        Serial.println("[ERROR] SPIFFS Mount Failed");
    }
    // Note: Do not load preferences here; caller should load before UI init when required.
    // WiFi connect or AP fallback
    WiFi.mode(WIFI_STA);
    WiFi.begin(saved_ssid.c_str(), saved_password.c_str());
    Serial.print("Connecting to WiFi");
    int tries = 0;
    while (WiFi.status() != WL_CONNECTED && tries < 30) {
        delay(500);
        Serial.print(".");
        tries++;
    }
    if (WiFi.status() == WL_CONNECTED) {
        Serial.println("\nWiFi connected!");
        Serial.print("IP: ");
        Serial.println(WiFi.localIP());
    } else {
        Serial.println("\nWiFi failed, starting AP mode");
        WiFi.mode(WIFI_AP);
        WiFi.softAP("ESP32-RoundDisplay", "12345678");
        Serial.print("AP IP: ");
        Serial.println(WiFi.softAPIP());
    }
    // Show fallback error screen if needed (after config load, before UI init)
    show_fallback_error_screen_if_needed();

    // Register web UI routes and start server
    config_server.on("/", handle_root);
    config_server.on("/gauges", handle_gauges_page);
    config_server.on("/save-gauges", HTTP_POST, handle_save_gauges);
    config_server.on("/network", handle_network_page);
    config_server.on("/save-wifi", HTTP_POST, handle_save_wifi);
    config_server.on("/test-gauge", HTTP_POST, handle_test_gauge);
    config_server.on("/toggle-test-mode", HTTP_POST, handle_toggle_test_mode);
    config_server.on("/nvs_test", HTTP_GET, handle_nvs_test);
    config_server.begin();
    Serial.println("[WebServer] Configuration web UI started on port 80");
}

bool is_wifi_connected() {
    return WiFi.status() == WL_CONNECTED;
}

String get_signalk_server_ip() {
    return saved_signalk_ip;
}

uint16_t get_signalk_server_port() {
    return saved_signalk_port;
}


String get_signalk_path_by_index(int idx) {
    if (idx >= 0 && idx < NUM_SCREENS * 2) return signalk_paths[idx];
    return "";
}

void handle_test_gauge() {
    if (config_server.method() == HTTP_POST) {
        int screen = config_server.arg("screen").toInt();
        int gauge = config_server.arg("gauge").toInt();
        int point = config_server.arg("point").toInt();
        int angle = config_server.hasArg("angle") ? config_server.arg("angle").toInt() : gauge_cal[screen][gauge][point].angle;
        extern void test_move_gauge(int screen, int gauge, int angle);
        extern bool test_mode;
        test_mode = true;
        test_move_gauge(screen, gauge, angle);
        // Respond with 204 No Content so the UI does not change
        config_server.send(204, "text/plain", "");
    } else {
        config_server.send(405, "text/plain", "Method Not Allowed");
    }
}

void handle_nvs_test() {
    if (config_server.method() != HTTP_GET) {
        config_server.send(405, "text/plain", "Method Not Allowed");
        return;
    }
    String resp = "";
    esp_err_t err;
    nvs_handle_t nh;
    uint8_t blob[4] = { 0x12, 0x34, 0x56, 0x78 };
    err = nvs_open(PREF_NAMESPACE, NVS_READWRITE, &nh);
    Serial.printf("[NVS TEST] nvs_open -> %s (%d)\n", esp_err_to_name(err), err);
    resp += String("nvs_open: ") + (err == ESP_OK ? esp_err_to_name(err) : String(err)) + "\n";
    if (err == ESP_OK) {
        err = nvs_set_blob(nh, "test_blob", blob, sizeof(blob));
        Serial.printf("[NVS TEST] nvs_set_blob -> %s (%d)\n", esp_err_to_name(err), err);
        resp += String("nvs_set_blob: ") + (err == ESP_OK ? esp_err_to_name(err) : String(err)) + "\n";
        err = nvs_commit(nh);
        Serial.printf("[NVS TEST] nvs_commit -> %s (%d)\n", esp_err_to_name(err), err);
        resp += String("nvs_commit: ") + (err == ESP_OK ? esp_err_to_name(err) : String(err)) + "\n";

        uint8_t readbuf[4] = {0,0,0,0};
        size_t rsz = sizeof(readbuf);
        err = nvs_get_blob(nh, "test_blob", readbuf, &rsz);
        Serial.printf("[NVS TEST] nvs_get_blob -> %s (%d) size=%u\n", esp_err_to_name(err), err, (unsigned)rsz);
        resp += String("nvs_get_blob: ") + (err == ESP_OK ? esp_err_to_name(err) : String(err)) + " size=" + String(rsz) + "\n";
        if (err == ESP_OK) {
            char bstr[64];
            snprintf(bstr, sizeof(bstr), "read: %02X %02X %02X %02X\n", readbuf[0], readbuf[1], readbuf[2], readbuf[3]);
            Serial.printf("[NVS TEST] read bytes: %02X %02X %02X %02X\n", readbuf[0], readbuf[1], readbuf[2], readbuf[3]);
            resp += String(bstr);
        }
        nvs_close(nh);
    }
    config_server.send(200, "text/plain", resp);
}
