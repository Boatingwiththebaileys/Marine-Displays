#include "ui.h"


// IMAGE DATA: assets/Fuel_Temp.bin (RGB565 binary)
const char *ui_img_fuel_temp_png = "S:/assets/Fuel_Temp.bin";
